package com.example.projet_android;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    public static final String PREFS_NAME = "SimonPrefs";
    public static final String SCORE1_KEY = "score1";
    public static final String SCORE2_KEY = "score2";
    public static final String SCORE3_KEY = "score3";
    public static final String NAME1_KEY = "name1";
    public static final String NAME2_KEY = "name2";
    public static final String NAME3_KEY = "name3";

    private TextView score1TextView, score2TextView, score3TextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialiser les vues
        score1TextView = findViewById(R.id.score1);
        score2TextView = findViewById(R.id.score2);
        score3TextView = findViewById(R.id.score3);

        // Afficher les meilleurs scores avec les noms des joueurs
        displayTopScores();

        // Gérer le clic sur le bouton "Jouer"
        Button playButton = findViewById(R.id.play_button);
        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startSimonGame(); // Fonction pour démarrer le jeu Simon
            }
        });

        // Gérer le clic sur le bouton "Quitter"
        Button quitButton = findViewById(R.id.quit_button);
        quitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Fermer l'application
            }
        });
    }

    private void displayTopScores() {
        // Récupérer les scores et les noms des joueurs à partir de SharedPreferences
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        int score1 = prefs.getInt(SCORE1_KEY, 0);
        int score2 = prefs.getInt(SCORE2_KEY, 0);
        int score3 = prefs.getInt(SCORE3_KEY, 0);
        String name1 = prefs.getString(NAME1_KEY, "");
        String name2 = prefs.getString(NAME2_KEY, "");
        String name3 = prefs.getString(NAME3_KEY, "");

        // Afficher les scores avec les noms des joueurs
        score1TextView.setText("1. " + name1 + ": " + score1);
        score2TextView.setText("2. " + name2 + ": " + score2);
        score3TextView.setText("3. " + name3 + ": " + score3);
    }

    private void startSimonGame() {
        Intent intent = new Intent(this, simonActivity.class);
        startActivity(intent); // Démarrer l'activité Simon
    }
}
