package com.example.projet_android;

import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class simonActivity extends AppCompatActivity {

    private List<Integer> sequence;
    private int currentStep;
    private int score;
    private SoundPool soundPool;
    private int soundRed, soundBlue, soundGreen, soundYellow, soundError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simon);

        // Initialize SoundPool
        soundPool = new SoundPool(2, AudioManager.STREAM_MUSIC, 0);

        // Load sound effects
        soundRed = soundPool.load(this, R.raw.son1, 1);
        soundBlue = soundPool.load(this, R.raw.son2, 1);
        soundGreen = soundPool.load(this, R.raw.son3, 1);
        soundYellow = soundPool.load(this, R.raw.son4, 1);
        soundError = soundPool.load(this, R.raw.error, 1); // Load error sound

        // Initialize variables
        sequence = new ArrayList<>();
        currentStep = 0;
        score = 0;

        // Initialize color buttons
        setupColorPads();

        // Start the game
        startGame();
    }

    private void setupColorPads() {
        Button colorPad1 = findViewById(R.id.color_pad_1);
        Button colorPad2 = findViewById(R.id.color_pad_2);
        Button colorPad3 = findViewById(R.id.color_pad_3);
        Button colorPad4 = findViewById(R.id.color_pad_4);

        colorPad1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleColorClick(1);
            }
        });

        colorPad2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleColorClick(2);
            }
        });

        colorPad3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleColorClick(3);
            }
        });

        colorPad4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleColorClick(4);
            }
        });
    }

    private void handleColorClick(int color) {
        if (color == sequence.get(currentStep)) {
            currentStep++;
            if (currentStep == sequence.size()) {
                // Correct color sequence reproduced
                score++;
                updateScore();
                addNextColorToSequence();
                currentStep = 0;
            }
        } else {
            // Wrong color, game over
            gameOver();
            // Play error sound
            playErrorSound();
        }
    }

    private void startGame() {
        // Start with a sequence of length 1
        addNextColorToSequence();
    }

    private void addNextColorToSequence() {
        Random random = new Random();
        int nextColor = random.nextInt(4) + 1; // Choose a random color from 1 to 4
        sequence.add(nextColor);
        // Display sequence to the player
        displaySequence();
    }

    private void displaySequence() {
        // Display color sequence to the player (e.g., by highlighting buttons)
        for (int i = 0; i < sequence.size(); i++) {
            final int color = sequence.get(i);
            Button button = getColorButton(color);
            button.postDelayed(new Runnable() {
                @Override
                public void run() {
                    highlightColor(color);
                }
            }, 1000 * i);
        }
    }

    private Button getColorButton(int color) {
        switch (color) {
            case 1:
                return findViewById(R.id.color_pad_1);
            case 2:
                return findViewById(R.id.color_pad_2);
            case 3:
                return findViewById(R.id.color_pad_3);
            case 4:
                return findViewById(R.id.color_pad_4);
            default:
                return null;
        }
    }

    private void highlightColor(int color) {
        Button button = getColorButton(color);
        if (button != null) {
            // Highlight the color
            button.setPressed(true);
            // Play sound corresponding to the color
            playSoundForColor(color);
            // Remove highlight after a short delay
            button.postDelayed(new Runnable() {
                @Override
                public void run() {
                    resetColor(color);
                }
            }, 500);
        }
    }

    private void resetColor(int color) {
        Button button = getColorButton(color);
        if (button != null) {
            // Reset color
            button.setPressed(false);
        }
    }

    private void playSoundForColor(int color) {
        switch (color) {
            case 1:
                soundPool.play(soundRed, 1, 1, 1, 0, 1);
                break;
            case 2:
                soundPool.play(soundBlue, 1, 1, 1, 0, 1);
                break;
            case 3:
                soundPool.play(soundGreen, 1, 1, 1, 0, 1);
                break;
            case 4:
                soundPool.play(soundYellow, 1, 1, 1, 0, 1);
                break;
        }
    }

    private void updateScore() {
        TextView scoreTextView = findViewById(R.id.score_label);
        scoreTextView.setText("Score: " + score);
    }

    private void gameOver() {
        // Display game over message
        // Toast.makeText(this, "Game Over! Score: " + score, Toast.LENGTH_SHORT).show();

        // Save score if it's among the top three
        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE);
        int topScore1 = prefs.getInt(MainActivity.SCORE1_KEY, 0);
        int topScore2 = prefs.getInt(MainActivity.SCORE2_KEY, 0);
        int topScore3 = prefs.getInt(MainActivity.SCORE3_KEY, 0);

        if (score > topScore1) {
            prefs.edit().putInt(MainActivity.SCORE1_KEY, score).apply();
            prefs.edit().putInt(MainActivity.SCORE2_KEY, topScore1).apply();
            prefs.edit().putInt(MainActivity.SCORE3_KEY, topScore2).apply();
        } else if (score > topScore2) {
            prefs.edit().putInt(MainActivity.SCORE2_KEY, score).apply();
            prefs.edit().putInt(MainActivity.SCORE3_KEY, topScore2).apply();
        } else if (score > topScore3) {
            prefs.edit().putInt(MainActivity.SCORE3_KEY, score).apply();
        }

        // Finish SimonActivity
        finish();
    }

    private void playErrorSound() {
        soundPool.play(soundError, 1, 1, 1, 0, 1);
    }
}
